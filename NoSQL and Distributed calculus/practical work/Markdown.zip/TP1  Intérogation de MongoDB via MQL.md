
### Partie I : Démarrage et importation d’une base de donnée

Structure de la bd

![[0_DB_NAME.png]]

Example of a document

![[0_DOCUMENT.png]]

### Partie II : Exploitation de la BD par requêtes

Ecrire et exécuter les requêtes MQL (MongoDB Query Language) suivantes:

1. Afficher les 200 premiers documents de la collection books.

```python
db.books.find().limit(200)
```

![[1_FIND_LIMIT.png]]

2. Afficher le titre, ISBN et le nombre de pages des livres classés dans la
catégorie « Internet ». Compter le nombre de livres affichés.

```python

db.books.find({categories:"Internet"},{_id:0,title:1,isbn:1,pageCount:1})

```

![[2_FILTER.png]]

3. Trier par ordre croissant des ISBN, les livres de l’auteur « David A. Black » et
ayant un nombre de page supérieur strictement à 300.

```python

db.books.find({authors:"David A. Black" ,pageCount:{$gt: 300}}).sort({isbn:1})

```

![[3.png]]

4. Trouver les livres dont le titre contient le mot « Action » et publiés en 2011.

```python

db.books.find({ title: /Action/i ,"publishedDate.date": /2011/ })

```

![[4.png]]

5. Ajouter un champ qui indique que les livres de MongoDB sont tous
empruntés par les étudiants.

```python

db.books.updateMany({title:{$regex:"MongoDB"}},{$set : {isBorrowed: true}})
```

![[5.png]]

6. Afficher la liste des livres (ISBN et titre) dont le nombre de pages est nul ou
la liste des auteurs est vide. Supprimer ces champs de ces documents s’ils
sont vides.

```python

db.books.deleteMany({$or: [{ numberOfPages: { $eq: 0 } },{ authors: { $size: 0 } }]},{_id:0,isbn:1,title:1})

```

![[6.png]]

7. Afficher la liste des auteurs (s’ils existent) qui publient dans la catégorie du
Microsoft (trier le résultat par ordre décroissant du nombre de pages).

```python

db.books.find({categories:"Microsoft", authors  :{ $exists: true}},{_id:0,authors:1,pageCount:1}).sort({pageCount:-1})

```

![[7.png]]

8. Ajouter deux auteurs, votre professeur et vous, aux livres ayant le mot clé
« Database » dans leurs titres.

```python

db.books.updateMany({title:{$regex:"Database"}},{$push : {authors: { $each : ["Soussi","Boulanouar"] }}})
```

![[8_ADD_AUTHORS.png]]

``` python

db.books.find({title:{$regex:"Database"}},{authors:1})

```

![[8_CHECK_AUTHORS.png]]

9. Sélectionner les livres qui n’appartient pas aux catégories "Business",
"Microsoft", "Microsoft.NET" et "In Action" et publiés en 2009 et 2011
(afficher juste le titre, date de publication et la catégorie)

```python

db.books.find(
        { categories: { $nin: ["Business","Microsoft.NET","In Action"] } ,
		 "publishedDate.date": {$in:  [/2009/,/2011/] }}
  ,{_id:0,title:1,publishedDate:1,categories:1})

```

![[9.png]]

10. Calculer la moyenne des pages pour chaque catégorie des livres et trier le
résultat par ordre décroissant de cette moyenne.

```python

db.books.aggregate([{$unwind: "$categories"},
				   {$group : 
				   {_id: "$categories" , 
				    moyennePage: { $avg: "$pageCount" } } },
				   {$sort : {pageCount:-1} }])

```

![[10.png]]

11. Trouver la liste des sujets (catégories) dont ils s’intéressent chaque auteur et
stocker le résultat dans une nouvelle collection.
Indication : se docummenter sur $addToSet.

```python
db.books.aggregate([
  {
    $unwind: "$authors" 
  },
  {
    $unwind: "$categories" 
  },
  {
    $group: {
      _id: {
        author: "$authors",
        category:  "$categories" 
      }
    }
  },
  {
    $sort: { "_id": 1 } 
  }
])

```

![[11.png]]